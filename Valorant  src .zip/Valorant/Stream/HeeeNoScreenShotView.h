
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HeeeNoScreenShotView : UIView
-(void)setsecure:(bool)swtich;
@end

NS_ASSUME_NONNULL_END
