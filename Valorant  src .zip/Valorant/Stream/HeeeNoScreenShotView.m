// HeeeNoScreenShotView.m
#import "HeeeNoScreenShotView.h"

@interface HeeeNoScreenShotView ()
@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) UIView *clearView;
@end

@implementation HeeeNoScreenShotView

- (instancetype)init {
    self = [super init];
    if (self) {
        [self setupUI];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupUI];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    if (self) {
        [self setupUI];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.textField.frame = self.bounds;
    self.clearView.frame = self.bounds;
}

- (void)setupUI {
    [self addSubview:self.textField];
    self.textField.subviews.firstObject.userInteractionEnabled = YES;
    [self.textField.subviews.firstObject addSubview:self.clearView];
    
    // 启用用户交互
    self.userInteractionEnabled = YES;
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hitView = [super hitTest:point withEvent:event];
    
    // 如果点击到的是防录屏相关视图，传递到下层
    if (hitView == self || hitView == self.textField || hitView == self.clearView) {
        // 查找子视图中的第一个响应者
        for (UIView *subview in self.clearView.subviews) {
            CGPoint convertedPoint = [self convertPoint:point toView:subview];
            UIView *targetView = [subview hitTest:convertedPoint withEvent:event];
            if (targetView) {
                return targetView;
            }
        }
        return nil;
    }
    
    return hitView;
}

- (void)addSubview:(UIView *)view {
    [super addSubview:view];
    if (self.textField != view) {
        [self.clearView addSubview:view];
    }
}

-(UITextField *)textField {
    if (!_textField) {
        _textField = [[UITextField alloc] init];
        _textField.secureTextEntry = YES;  // 防录屏
        _textField.userInteractionEnabled = NO;  // 禁用输入
    }
    return _textField;
}

- (UIView *)clearView {
    if (!_clearView) {
        _clearView = [[UIView alloc] init];
        _clearView.userInteractionEnabled = YES;  // 允许交互以传递事件
    }
    return _clearView;
}

- (void)setsecure:(bool)swtich {
    self.textField.secureTextEntry = swtich;
}

@end
