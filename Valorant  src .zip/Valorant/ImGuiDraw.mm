// Created by chunmod on 2025/05/12.
// Telegram: @chunmodvn

#import "ImGuiView.h"
#import "ImGuiDraw.h"
#import "Stream/HeeeNoScreenShotView.h"
#import "OBF/mahoa.h"
#import "fishhook/hook.h"
#import "fishhook/patch.h"
#include <vector>
#include "Other/nav_elements.h"
#include "Other/etc_elements.h"

#define kuan [UIScreen mainScreen].bounds.size.width // 1194
#define gao [UIScreen mainScreen].bounds.size.height // 834
#define Scalesi [UIScreen mainScreen].nativeScale


bool Masskill; 
enum heads {
    rage, antiaim, visuals, settings
};

enum sub_heads {
    general, accuracy, exploits, _general, advanced
};

static heads tab{ rage };
static sub_heads subtab{ general };

const ImColor tab_colors[3] = { ImColor(255, 0, 0), ImColor(255, 165, 0), ImColor(0, 128, 0) };

static uintptr_t moudule_base;

const char *CurrentHealthBar;
const char *MaxHealthBar;
const char *WorldAddress;
const char *kGetViewportSize;
const char *kProjectWorldLocationToScreen;
const char *kLineOfSight_1;
const char *kLineOfSight_2;
const char *kLineOfSight_3;
const char *kLineOfSight_4;
const char *kLineOfSight_5;

static Vector2 CanvasSize;
static CGSize screenSize;

static int totalEnemies, AItotalEnemies = 0;

static long GWorld, UName;
static long Character, WeaponID;
static long PlayerController, Pawn;
static long PlayerCameraManager;
static MinimalViewInfo POV;
static long ControlRotation;
static bool isFiring;
static bool isGunADS;
static int MyTeamId;
static int ZCMyTeamId;
static float (*GetHealth)(void *actor);
static float (*GetHealthMax)(void *actor);
static char PlayerName[100];
static float aimSpeed = 1.0f; // Tốc độ tự ngắm
static float AimBotFOV = 100.0f; // Phạm vi tự ngắm
static float wuzi;
static float yq = 0.0;
static FRotator aimRotation;
static float tDistance = 0;
static NSString *bundle;
static int ratioCustom = 3;





// Thêm vào khu vực định nghĩa biến bool khác
bool AntiScreenRecordSwitch = true;
static HeeeNoScreenShotView *AntiScreenRecordView = nil; // Thực thể của giao diện chống ghi màn hình

static NSTimer *offsetUpdateTimer = nil; // Thêm vào khu vực biến toàn cục, gọi địa chỉ server nền

UIButton *floatingButton;
static const char* GetBoneFTransformName(int index); // Tuyên bố hàm điểm đánh
bool isMenuVisible = false;
bool TeamCheckSwitch;
bool BattlefieldSwitch;

bool AIDisplay;
//bool BoxSwitch, HelmetArmorSwitch, PlayerName, DistanceSwitch, RaySwitch, HealthSwitch, SkeletonSwitch, NoChaseDowned;
bool BoxSwitch, HelmetArmorSwitch, PlayerNameSwitch, DistanceSwitch, HealthSwitch, SkeletonSwitch, NoChaseDowned;

bool NoRecoilSwitch, StrongholdSwitch;
bool CrateSwitch, CrateItems, MapItems;
bool TrackingSwitch;
bool AimBotSwitch;

bool LineSwitch;
// Thêm vào khu vực biến toàn cục:
static int selectedBoneIndex = 1; // Mặc định là 3 (ngực)
bool EnableSwitch;

float sliderValue1;
float sliderValue2;
float sliderValue3;
float sliderValue4;

typedef uintptr_t kaddr;
uintptr_t anogs;

// Function prototypes
void SaveSettings();
void LoadSettings();
void ToggleMenuVisibility();
void MyMenu();
void ReaMemData();




extern void MyMenu() {
    if (!isMenuVisible) {
        return;
    }

    // Set font scale for better readability
    ImFont* font = ImGui::GetFont();
            font->Scale = 15.f / font->FontSize;


CGFloat x = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width) - 450) / 2;
            CGFloat y = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height) - 255) / 2;
            
ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);

const char* tab_name = tab == rage ? "GoodByte" : tab == antiaim ? "AimBot" : tab == visuals ? "Memory" : tab == settings ? "Settings" : 0;
        const char* tab_icon = tab == rage ? "E" : tab == antiaim ? "C" : tab == visuals ? "F" : tab == settings ? "E" : 0;

        static bool boolean, boolean_1, boolean_2, boolean_3 = false;

        static int sliderscalar, combo = 0;

        const char* box_names[3] = { "Default", "Box 3D", "Box Conner" };

        static int sliderscalar1, combo1 = 0;

            
           
            ImGui::SetNextWindowSize({ 500, 360 });
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, { 0, 0 });

        ImGui::Begin("##hi", nullptr, ImGuiWindowFlags_NoDecoration); {


            auto draw = ImGui::GetWindowDrawList();
            auto pos = ImGui::GetWindowPos();
            auto size = ImGui::GetWindowSize();
            
            ImGuiStyle style = ImGui::GetStyle();

            draw->AddRectFilled(pos, ImVec2(pos.x + 144, pos.y + size.y), ImColor(24, 24, 26), style.WindowRounding, ImDrawFlags_RoundCornersLeft);


            draw->AddLine(ImVec2(pos.x + 144, pos.y + 1.5), ImVec2(pos.x + 144, pos.y + size.y - 1.5), ImColor(1.0f, 1.0f, 1.0f, 0.03f));



            //draw->AddText(tab_title_icon, 18.0f, ImVec2(pos.x + 20, pos.y + 11), ImColor(6, 249, 249), tab_icon);

//draw->AddText(tab_title, 19.0f, ImVec2(pos.x + 40, pos.y + 11), ImColor(1.0f, 1.0f, 1.0f), tab_name);
switch (tab) {
  case rage:

ImGui::SetCursorPos({ 8, 46 });
                ImGui::BeginGroup(); {
                    if (elements::subtab("Main ESP", subtab == general)) { subtab = general; }
                    if (elements::subtab("Aimbot", subtab == accuracy)) { subtab = accuracy; }
                    if (elements::subtab("Setup", subtab == exploits)) { subtab = exploits; }

if (elements::subtab("Other", subtab == _general)) { subtab = _general; }

//if (elements::subtab("Info", subtab == advanced)) { subtab = advanced; }
                } 
break;
case antiaim:
break;
case visuals:
break;
case settings:

ImGui::EndGroup();
}

switch (subtab) {
case general:
ImGui::SetCursorPos({ 154, 12 });
                    e_elements::begin_child("Main ESP", ImVec2(164, 340)); {
                        
                        if (ImGui::Checkbox("Enable Cheat", &EnableSwitch)) {
                                  }

                        ImGui::Checkbox("AI Drawing", &AIDisplay);
                        ImGui::Checkbox("Operator mode", &TeamCheckSwitch);
                        ImGui::Checkbox("Player Distance", &DistanceSwitch);
                        ImGui::Checkbox("Player Name", &PlayerNameSwitch);
                        ImGui::Checkbox("Crate Switch", &CrateSwitch);
                        ImGui::Checkbox("Map Items", &MapItems);
                        
                        
                        


        }
                    e_elements::end_child();

                    ImGui::SetCursorPos({ 326, 12 });
                    e_elements::begin_child("Draw ESP", ImVec2(164, 340)); {

                        ImGui::Checkbox("Skip Downed", &NoChaseDowned);
                        ImGui::Checkbox("Player Health", &HealthSwitch);
                        ImGui::Checkbox("Player Skeleton", &SkeletonSwitch);
                        ImGui::Checkbox("Draw Line", &LineSwitch);
                        ImGui::Checkbox("Helmet/Armor", &HelmetArmorSwitch);
                        ImGui::Checkbox("Box Switch", &BoxSwitch);
                       




                

                    }
                    e_elements::end_child();
//SUB TAB 2                    
break;
case accuracy:
ImGui::SetCursorPos({ 154, 12 });
                    e_elements::begin_child("Aimbot Swich", ImVec2(164, 340)); {
         

            
            ImGui::Checkbox("AimBot Enable", &AimBotSwitch);
          
            
            ImGui::SliderFloat("Aim Speed", &aimSpeed, 0.0f, 1.0f, "%.2f");
            ImGui::SliderFloat("Aim FOV", &AimBotFOV, 0.0f, 300.0f, "%.2f");
            ImGui::SliderFloat("Skip Item Level", &wuzi, 0.0f, 6.0f, "%.0f");
      

            
            
        }
                    e_elements::end_child();

                    ImGui::SetCursorPos({ 326, 12 });
                    e_elements::begin_child("Aimbot Target", ImVec2(164, 340)); {
                        ImGui::Text("Hit Target");
                        ImGui::Spacing();
                        
                        // Modern style for radio buttons
                        ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0.15f, 0.15f, 0.18f, 1.0f));
                        ImGui::PushStyleColor(ImGuiCol_CheckMark, ImVec4(0.0f, 0.8f, 0.4f, 1.0f));
                        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(6, 3)); // Reduced padding
                        
                        const char* boneNames[] = {
                            "Head", "Neck", "Chest", "Waist", "Pelvis",
                            "Left Shoulder", "Left Hand", "Right Shoulder", "Right Hand",
                            "Left Thigh", "Left Foot", "Right Thigh", "Right Foot"
                        };
                        
                        // Create a scrollable child window with reduced height
                        ImGui::BeginChild("HitPositionRadio", ImVec2(ImGui::GetWindowWidth() - 20, 160), true);
                        
                        // Calculate items per row based on window width with reduced button width
                        float itemWidth = 112.0f; // Reduced by 20% from 140
                        int itemsPerRow = (int)(ImGui::GetWindowWidth() / itemWidth);
                        if (itemsPerRow < 1) itemsPerRow = 1;
                        
                        for (int i = 0; i < IM_ARRAYSIZE(boneNames); i++) {
                            if (i > 0 && i % itemsPerRow != 0) {
                                ImGui::SameLine();
                            }
                            
                            // Create a button-like radio button with reduced size
                            ImGui::PushStyleColor(ImGuiCol_Button, selectedBoneIndex == i ? 
                                ImVec4(0.0f, 0.8f, 0.4f, 0.3f) : ImVec4(0.15f, 0.15f, 0.18f, 1.0f));
                            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.0f, 0.8f, 0.4f, 0.4f));
                            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.0f, 0.8f, 0.4f, 0.5f));
                            
                            if (ImGui::Button(boneNames[i], ImVec2(itemWidth - 10, 24))) { // Reduced height from 30 to 24
                                selectedBoneIndex = i;
                            }
                            
                            ImGui::PopStyleColor(3);
                        }
                        
                        ImGui::EndChild();
                        ImGui::PopStyleVar();
                        ImGui::PopStyleColor(2);
                    }
                    e_elements::end_child();


//SubTab 3

        break;
 case exploits:

ImGui::SetCursorPos({ 154, 12 });
                    e_elements::begin_child("Other Settings", ImVec2(328, 340)); {
                        
                   

            ImGui::BeginChild("SteamMode", ImVec2(0, 200), true);
            ImGui::PushStyleColor(ImGuiCol_CheckMark, ImVec4(1.0f, 0.2f, 0.2f, 1.0f));
            ImGui::Checkbox("Anti-Screen Recording", &AntiScreenRecordSwitch);
            ImGui::PopStyleColor();
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();
            
            // Save button
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.2f, 0.6f, 0.2f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.3f, 0.7f, 0.3f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.4f, 0.8f, 0.4f, 1.0f));
            
            if (ImGui::Button("Save Settings", ImVec2(ImGui::GetWindowWidth() - 30, 30))) {
                SaveSettings();
            }
        }
                    e_elements::end_child();


//SubTab 4

        break;
 case _general:

//SubTab 5

        break;
 //case advanced:
//break;
           
        }
        ImGui::End();
}

    

    // Restore styles
    ImGui::PopStyleVar(11);
    ImGui::PopStyleColor(19);
}

void ToggleMenuVisibility() {
    isMenuVisible = !isMenuVisible; // Chuyển đổi hiển thị menu
    // Lưu trạng thái menu
    [[NSUserDefaults standardUserDefaults] setBool:isMenuVisible forKey:@"isMenuVisible"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

// Hàm lưu cài đặt
void SaveSettings() {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    // Lưu các cài đặt Drawing
    [defaults setBool:EnableSwitch forKey:@"EnableSwitch"];
    [defaults setBool:AIDisplay forKey:@"AIDisplay"];
    [defaults setBool:BoxSwitch forKey:@"BoxSwitch"];
    [defaults setBool:DistanceSwitch forKey:@"DistanceSwitch"];
    [defaults setBool:PlayerNameSwitch forKey:@"PlayerNameSwitch"];
    [defaults setBool:CrateSwitch forKey:@"CrateSwitch"];
    [defaults setBool:NoChaseDowned forKey:@"NoChaseDowned"];
    [defaults setBool:TeamCheckSwitch forKey:@"TeamCheckSwitch"];
    [defaults setBool:SkeletonSwitch forKey:@"SkeletonSwitch"];
    [defaults setBool:HealthSwitch forKey:@"HealthSwitch"];
    [defaults setBool:LineSwitch forKey:@"LineSwitch"];
    [defaults setBool:HelmetArmorSwitch forKey:@"HelmetArmorSwitch"];
    [defaults setBool:NoRecoilSwitch forKey:@"NoRecoilSwitch"];
    [defaults setBool:MapItems forKey:@"MapItems"];
    
    // Lưu các cài đặt AimBot
    [defaults setBool:AimBotSwitch forKey:@"AimBotSwitch"];
    [defaults setFloat:aimSpeed forKey:@"aimSpeed"];
    [defaults setFloat:AimBotFOV forKey:@"AimBotFOV"];
    [defaults setFloat:wuzi forKey:@"wuzi"];
    [defaults setInteger:selectedBoneIndex forKey:@"selectedBoneIndex"];
    
    // Lưu các cài đặt khác
    [defaults setBool:AntiScreenRecordSwitch forKey:@"AntiScreenRecordSwitch"];
    
    [defaults synchronize];
}

// Hàm tải cài đặt
void LoadSettings() {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    // Tải các cài đặt Drawing
    EnableSwitch = [defaults boolForKey:@"EnableSwitch"];
    AIDisplay = [defaults boolForKey:@"AIDisplay"];
    BoxSwitch = [defaults boolForKey:@"BoxSwitch"];
    DistanceSwitch = [defaults boolForKey:@"DistanceSwitch"];
    PlayerNameSwitch = [defaults boolForKey:@"PlayerNameSwitch"];
    CrateSwitch = [defaults boolForKey:@"CrateSwitch"];
    NoChaseDowned = [defaults boolForKey:@"NoChaseDowned"];
    TeamCheckSwitch = [defaults boolForKey:@"TeamCheckSwitch"];
    SkeletonSwitch = [defaults boolForKey:@"SkeletonSwitch"];
    HealthSwitch = [defaults boolForKey:@"HealthSwitch"];
    LineSwitch = [defaults boolForKey:@"LineSwitch"];
    HelmetArmorSwitch = [defaults boolForKey:@"HelmetArmorSwitch"];
    NoRecoilSwitch = [defaults boolForKey:@"NoRecoilSwitch"];
    MapItems = [defaults boolForKey:@"MapItems"];
    
    // Tải các cài đặt AimBot
    AimBotSwitch = [defaults boolForKey:@"AimBotSwitch"];
    aimSpeed = [defaults floatForKey:@"aimSpeed"];
    AimBotFOV = [defaults floatForKey:@"AimBotFOV"];
    wuzi = [defaults floatForKey:@"wuzi"];
    selectedBoneIndex = (int)[defaults integerForKey:@"selectedBoneIndex"];
    
    // Tải các cài đặt khác
    AntiScreenRecordSwitch = [defaults boolForKey:@"AntiScreenRecordSwitch"];
}

static const char* GetBoneFTransformName(int index) {
    switch(index) {
        case 0: return "Head";
        case 1: return "Neck";
        case 2: return "Upper Chest";
        case 3: return "Chest";
        case 4: return "Waist";
        case 5: return "Pelvis";
        case 6: return "Left Shoulder";
        case 7: return "Left Upper Arm";
        case 8: return "Left Hand";
        case 9: return "Right Shoulder";
        case 10: return "Right Upper Arm";
        case 11: return "Right Hand";
        case 12: return "Left Thigh";
        case 13: return "Left Calf";
        case 14: return "Left Foot";
        case 15: return "Right Thigh";
        case 16: return "Right Calf";
        case 17: return "Right Foot";
        default: return "Unknown";
    }
}

sdkafowanbnonowaf * Global_DrawView;
Renderer *g_renderer;

@implementation sdkafowanbnonowaf

- (id)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hitView = [super hitTest:point withEvent:event];

    // Cập nhật vị trí chuột ImGui
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(point.x, point.y);

    // Nếu menu hiển thị và click trong cửa sổ ImGui
    if (isMenuVisible && ImGui::IsWindowHovered(ImGuiHoveredFlags_AnyWindow)) {
        return hitView;
    }

    return nil;
}

- (void)updateIOWithTouchEvent:(UIEvent *)event {
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches) {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled) {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self updateIOWithTouchEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self updateIOWithTouchEvent:event];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self updateIOWithTouchEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self updateIOWithTouchEvent:event];
}

+ (void)addFloatingButton {
    floatingButton = [UIButton buttonWithType:UIButtonTypeCustom];
    floatingButton.frame = CGRectMake(50, 50, 40, 40);
    floatingButton.backgroundColor = [UIColor clearColor];
    floatingButton.layer.cornerRadius = 20;
    floatingButton.clipsToBounds = YES;
    
    // Thêm vòng tròn xung quanh nút
    floatingButton.layer.borderWidth = 2.0f;
    floatingButton.layer.borderColor = [UIColor colorWithRed:1.0f green:0.2f blue:0.2f alpha:0.8f].CGColor;
    floatingButton.layer.shadowColor = [UIColor blackColor].CGColor;
    floatingButton.layer.shadowOffset = CGSizeMake(0, 2);
    floatingButton.layer.shadowOpacity = 0.3f;
    floatingButton.layer.shadowRadius = 3.0f;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        // Delay 1 giây trước khi load icon
        [NSThread sleepForTimeInterval:1.0];
        
        NSURL *imageURL = [NSURL URLWithString:@"https://cdn-icons-png.flaticon.com/512/869/869869.png"];
        NSData *imageData = [NSData dataWithContentsOfURL:imageURL];
        
        if (imageData) {
            dispatch_async(dispatch_get_main_queue(), ^{
                UIImage *buttonImage = [UIImage imageWithData:imageData];
                if (buttonImage) {
                    [floatingButton setImage:buttonImage forState:UIControlStateNormal];
                    floatingButton.imageView.contentMode = UIViewContentModeScaleAspectFill;
                }
            });
        }
    });
    [floatingButton addTarget:self action:@selector(toggleMenu) forControlEvents:UIControlEventTouchUpInside];
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanGesture:)];
    [floatingButton addGestureRecognizer:panGesture];

    [NSTimer scheduledTimerWithTimeInterval:5.0 target:self selector:@selector(ensureFloatingButtonVisible:) userInfo:@{ @"button": floatingButton } repeats:YES];
}

+ (void)ensureFloatingButtonVisible:(NSTimer *)timer {
    UIButton *floatingButton = timer.userInfo[@"button"];
    if (floatingButton.superview == nil) {
        UIScene *activeScene = [UIApplication sharedApplication].connectedScenes.allObjects.firstObject;
        if ([activeScene isKindOfClass:[UIWindowScene class]]) {
            UIWindow *currentWindow = ((UIWindowScene *)activeScene).windows.firstObject;
            [currentWindow addSubview:floatingButton];
        }
    }
}

+ (void)toggleMenu {
    ToggleMenuVisibility();
}

// Xử lý cử chỉ kéo
+ (void)handlePanGesture:(UIPanGestureRecognizer *)gesture {
    UIView *floatingButton = gesture.view;
    CGPoint translation = [gesture translationInView:floatingButton.superview];

    floatingButton.center = CGPointMake(floatingButton.center.x + translation.x, floatingButton.center.y + translation.y);

    CGRect superviewBounds = floatingButton.superview.bounds;
    CGFloat halfWidth = floatingButton.bounds.size.width / 2;
    CGFloat halfHeight = floatingButton.bounds.size.height / 2;
    floatingButton.center = CGPointMake(
        MAX(halfWidth, MIN(superviewBounds.size.width - halfWidth, floatingButton.center.x)),
        MAX(halfHeight, MIN(superviewBounds.size.height - halfHeight, floatingButton.center.y))
    );

    [gesture setTranslation:CGPointZero inView:floatingButton.superview];
}

#include "ESP.h"
void _function_return1(void *_this) { return; }
void _function_return2(void *_this) { return; }
void _function_return3(void *_this) { return; }
void _function_4(void *_this) { return; }
void _function_5(void *_this) { return; }
void _function_6(void *_this) { return; }

void showToast(NSString *message) {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        UILabel *toastLabel = [[UILabel alloc] initWithFrame:CGRectMake(window.center.x - 100, window.center.y - 50, 200, 50)];
        toastLabel.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.7];
        toastLabel.textColor = [UIColor redColor];
        toastLabel.textAlignment = NSTextAlignmentCenter;
        toastLabel.text = message;
        toastLabel.alpha = 1.0;
        toastLabel.layer.cornerRadius = 10;
        toastLabel.clipsToBounds = YES;
        [window addSubview:toastLabel];
        [UIView animateWithDuration:3.0 delay:1.0 options:UIViewAnimationOptionCurveEaseOut animations:^{ toastLabel.alpha = 0.0; } completion:^(BOOL finished) { [toastLabel removeFromSuperview]; }];
    });
}

void hook_no_orig_function() {
    showToast(@"[TW-1 TG@TW_1_MOD]-Antiban!");
    hook(
        (void *[]) {
            (void *)getAbsoluteAddress("anogs", ENCRYPTOFFSET("0x1e250")),
            (void *)getAbsoluteAddress("anogs", ENCRYPTOFFSET("0x1e330")),
            (void *)getAbsoluteAddress("anogs", ENCRYPTOFFSET("0x991e4")),
            (void *)getAbsoluteAddress("anogs", ENCRYPTOFFSET("0xd15bc")),
            (void *)getAbsoluteAddress("anogs", ENCRYPTOFFSET("0x1c60f0")),
            (void *)getAbsoluteAddress("anogs", ENCRYPTOFFSET("0x1ed020"))
        },
        (void *[]) {
            (void *)_function_return1,
            (void *)_function_return2,
            (void *)_function_return3,
            (void *)_function_4,
            (void *)_function_5,
            (void *)_function_6
        },
        6
    );
}

static void __attribute__((constructor)) CosmkloadYZ() {
    dispatch_async(dispatch_get_main_queue(), ^{
        // Delay 1 giây trước khi khởi tạo API
        // [NSThread sleepForTimeInterval:1.0];
        
        // APIClient *API = [[APIClient alloc] init];
        // NSString *token = originalToken;
        // [API setToken:token];
        // [API setLanguage:NSSENCRYPT("vi")];
        // [API hideUI:NO]; // Đảm bảo UI key được hiển thị

        // [API paid:^{
            

   //antiban Jaibreak
             /*   
                vm_anogs(ENCRYPTOFFSET("0x103b1c"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
                vm_anogs(ENCRYPTOFFSET("0x103e54"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
                vm_anogs(ENCRYPTOFFSET("0x1c28b4"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
                vm_anogs(ENCRYPTOFFSET("0x227760"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
                vm_anogs(ENCRYPTOFFSET("0x2ac958"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
                vm_anogs(ENCRYPTOFFSET("0x2b0abc"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
             
  */
            // Tải cài đặt đã lưu
            LoadSettings();
            
            // Khởi tạo screenSize
            screenSize = [UIScreen mainScreen].bounds.size;
            screenSize.width *= [UIScreen mainScreen].nativeScale;
            screenSize.height *= [UIScreen mainScreen].nativeScale;

            // Tạo floating button trước
            floatingButton = [UIButton buttonWithType:UIButtonTypeCustom];
            floatingButton.frame = CGRectMake(50, 50, 40, 40);
            floatingButton.backgroundColor = [UIColor clearColor];
            floatingButton.layer.cornerRadius = 20;
            floatingButton.clipsToBounds = YES;
            
            // Thêm vòng tròn xung quanh nút
            floatingButton.layer.borderWidth = 2.0f;
            floatingButton.layer.borderColor = [UIColor colorWithRed:1.0f green:0.2f blue:0.2f alpha:0.8f].CGColor;
            floatingButton.layer.shadowColor = [UIColor blackColor].CGColor;
            floatingButton.layer.shadowOffset = CGSizeMake(0, 2);
            floatingButton.layer.shadowOpacity = 0.3f;
            floatingButton.layer.shadowRadius = 3.0f;
            
            // Load icon trực tiếp từ URL với retry mechanism
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                // Delay 1 giây trước khi load icon
                [NSThread sleepForTimeInterval:1.0];
                
                NSURL *imageURL = [NSURL URLWithString:@"https://cdn-icons-png.flaticon.com/512/869/869869.png"];
                NSData *imageData = [NSData dataWithContentsOfURL:imageURL];
                
                if (imageData) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UIImage *buttonImage = [UIImage imageWithData:imageData];
                        if (buttonImage) {
                            [floatingButton setImage:buttonImage forState:UIControlStateNormal];
                            floatingButton.imageView.contentMode = UIViewContentModeScaleAspectFill;
                        }
                    });
                }
            });
            
            [floatingButton addTarget:[sdkafowanbnonowaf class] action:@selector(toggleMenu) forControlEvents:UIControlEventTouchUpInside];
            UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:[sdkafowanbnonowaf class] action:@selector(handlePanGesture:)];
            [floatingButton addGestureRecognizer:panGesture];

            // Thêm floating button vào window ngay lập tức
            UIScene *activeScene = [UIApplication sharedApplication].connectedScenes.allObjects.firstObject;
            if ([activeScene isKindOfClass:[UIWindowScene class]]) {
                UIWindow *currentWindow = ((UIWindowScene *)activeScene).windows.firstObject;
                [currentWindow addSubview:floatingButton];
            }

            // Timer kiểm tra và đảm bảo floating button luôn hiển thị
            [NSTimer scheduledTimerWithTimeInterval:5.0 target:[sdkafowanbnonowaf class] selector:@selector(ensureFloatingButtonVisible:) userInfo:@{ @"button": floatingButton } repeats:YES];
            uint32_t count = _dyld_image_count();
                for (int i = 0; i < count; i++) {
                    std::string path = (const char *)_dyld_get_image_name(i);
                    if (path.find("CodeV.app/CodeV") != path.npos) moudule_base = _dyld_get_image_vmaddr_slide(i);
                }
            // Tăng delay lên 4 giây để khởi tạo các thành phần khác
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    bundle = [[NSBundle mainBundle] bundleIdentifier];
    bundle = [NSString stringWithFormat:@"%@", bundle];
    
    char *showBundle = (char*) [bundle cStringUsingEncoding:NSUTF8StringEncoding];

    if (strstr(showBundle, ".proxima") != NULL || strstr(showBundle, ".dfm") != NULL || strstr(showBundle, "com.proxima.dfm") != NULL ) {
                    // Phiên bản quốc tế
                    CurrentHealthBar = "0x102C8EAFC";
                    MaxHealthBar = "0x102C9C1AC";
                    WorldAddress = "0x1104F7478";
                    kGetViewportSize = "0x106E51854";
                    kProjectWorldLocationToScreen = "0x106C83FE8";
                    kLineOfSight_1 = "0x1102871C0";
                    kLineOfSight_2 = "0x1104D9534";
                    kLineOfSight_3 = "0x106B77CDC";
                    kLineOfSight_4 = "0x106B78530";
                    kLineOfSight_5 = "0x10ACBCBAC";
                }

    else if (strstr(showBundle, ".garena") != NULL || strstr(showBundle, ".game") != NULL || strstr(showBundle, "com.garena.game.df") != NULL) {
                    // Phiên bản Garena
                    CurrentHealthBar = "0x102AC82D0";
                    MaxHealthBar = "0x102AD5980";
                    WorldAddress = "0x1102B30F8";
                    kGetViewportSize = "0x106C8A918";
                    kProjectWorldLocationToScreen = "0x106ABD0AC";
                    kLineOfSight_1 = "0x110043000";
                    kLineOfSight_2 = "0x1102951B4";
                    kLineOfSight_3 = "0x1069B0DA0";
                    kLineOfSight_4 = "0x1069B15F4";
                    kLineOfSight_5 = "0x10AAEC854";
                }

                // Tạo giao diện chống ghi màn hình
                AntiScreenRecordView = [[HeeeNoScreenShotView alloc] initWithFrame:CGRectMake(
                    [UIScreen mainScreen].bounds.origin.x,
                    [UIScreen mainScreen].bounds.origin.y,
                    [UIScreen mainScreen].bounds.size.width,
                    [UIScreen mainScreen].bounds.size.height)];
                [AntiScreenRecordView setBackgroundColor:[UIColor clearColor]];

                // Tạo giao diện vẽ
                Global_DrawView = [[sdkafowanbnonowaf alloc] initWithFrame:CGRectMake(
                    [UIScreen mainScreen].bounds.origin.x,
                    [UIScreen mainScreen].bounds.origin.y,
                    [UIScreen mainScreen].bounds.size.width,
                    [UIScreen mainScreen].bounds.size.height)];
                Global_DrawView.device = MTLCreateSystemDefaultDevice();
                Global_DrawView.preferredFramesPerSecond = 60;
                g_renderer = [[Renderer alloc] initWithMetalKitView:Global_DrawView];
                Global_DrawView.delegate = g_renderer;
                [Global_DrawView setBackgroundColor:[UIColor clearColor]];

                // Thêm các view vào window
                UIScene *activeScene = [UIApplication sharedApplication].connectedScenes.allObjects.firstObject;
                if ([activeScene isKindOfClass:[UIWindowScene class]]) {
                    UIWindow *currentWindow = ((UIWindowScene *)activeScene).windows.firstObject;
                    UIView *transitionView = currentWindow.subviews.firstObject;
                    UIView *shadowView = transitionView.subviews.firstObject;
                    UIView *contentView = shadowView.subviews.firstObject;
                    UIView *containerView = contentView.subviews.firstObject;

                    [containerView addSubview:AntiScreenRecordView];
                    [AntiScreenRecordView addSubview:Global_DrawView];
                }
            });
        // }];
    });
}



@end



